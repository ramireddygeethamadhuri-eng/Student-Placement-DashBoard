import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { fetchAnnouncements, fetchJobs } from "../api/api.js";
import { daysLeft } from "../api/format.js";
import { useAuth } from "./AuthContext.jsx";

const AppContext = createContext(null);
export const STATUSES = ["Applied", "Shortlisted", "Interview Scheduled", "Selected"];

export function AppProvider({ children }) {
  const { user } = useAuth();
  const [jobs, setJobs] = useState([]);
  const [announcements, setAnnouncements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [applications, setApplications] = useState([]);

  const storageKey = user ? `spd_apps_${user.email}` : null;

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const [j, a] = await Promise.all([fetchJobs(), fetchAnnouncements()]);
      setJobs(j);
      setAnnouncements(a);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (!storageKey) return setApplications([]);
    try {
      setApplications(JSON.parse(localStorage.getItem(storageKey)) || []);
    } catch {
      setApplications([]);
    }
  }, [storageKey]);

  const save = (next) => {
    setApplications(next);
    try { localStorage.setItem(storageKey, JSON.stringify(next)); } catch { /* ignore */ }
  };

  const apply = (job) => {
    if (applications.some((a) => a.jobId === job.id)) return { ok: false, message: "You already applied to this job." };
    if (daysLeft(job.deadline) < 0) return { ok: false, message: "The deadline for this job has passed." };
    if (Number(user.cgpa) < job.minCgpa) return { ok: false, message: `Minimum CGPA for this job is ${job.minCgpa}. Update your profile if your CGPA has changed.` };
    save([...applications, {
      jobId: job.id, company: job.company, role: job.role,
      appliedOn: new Date().toISOString().slice(0, 10),
      status: "Applied", interviewDate: job.interviewDate,
    }]);
    return { ok: true, message: `Applied to ${job.company}.` };
  };

  // Demo helper: moves an application to the next stage so you can see every status.
  const advance = (jobId) =>
    save(applications.map((a) => {
      if (a.jobId !== jobId) return a;
      const i = STATUSES.indexOf(a.status);
      return { ...a, status: STATUSES[Math.min(i + 1, STATUSES.length - 1)] };
    }));

  const notifications = useMemo(() => {
    const interviews = applications
      .filter((a) => a.status === "Interview Scheduled")
      .map((a) => ({ id: `int-${a.jobId}`, type: "interview", title: `Interview with ${a.company}`, text: `${a.role}. Prepare for your technical and HR rounds.`, date: a.interviewDate }));
    return { interviews, others: announcements };
  }, [applications, announcements]);

  return (
    <AppContext.Provider value={{ jobs, loading, error, reload: load, applications, apply, advance, notifications }}>
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => useContext(AppContext);
