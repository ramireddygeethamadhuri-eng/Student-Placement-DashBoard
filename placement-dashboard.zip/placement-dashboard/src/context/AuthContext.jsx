import { createContext, useContext, useEffect, useState } from "react";

const AuthContext = createContext(null);
const USERS_KEY = "spd_users";
const SESSION_KEY = "spd_session";

// NOTE: localStorage auth is for learning/demo only. Real apps need a backend with hashed passwords.
const read = (key, fallback) => {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
};
const write = (key, value) => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage unavailable */
  }
};

const demoUser = {
  name: "Demo Student", email: "demo@student.edu", password: "Demo@1234",
  branch: "AIML", cgpa: 8.1, phone: "9876543210", skills: "Python, React, SQL",
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const users = read(USERS_KEY, []);
    if (!users.some((u) => u.email === demoUser.email)) write(USERS_KEY, [...users, demoUser]);
    const email = read(SESSION_KEY, null);
    const found = read(USERS_KEY, []).find((u) => u.email === email);
    if (found) setUser(found);
    setReady(true);
  }, []);

  const register = (data) => {
    const users = read(USERS_KEY, []);
    const email = data.email.toLowerCase();
    if (users.some((u) => u.email === email)) throw new Error("An account with this email already exists.");
    const newUser = { ...data, email, phone: "", skills: "" };
    write(USERS_KEY, [...users, newUser]);
    write(SESSION_KEY, email);
    setUser(newUser);
  };

  const login = (email, password) => {
    const found = read(USERS_KEY, []).find((u) => u.email === email.toLowerCase());
    if (!found || found.password !== password) throw new Error("Email or password is incorrect.");
    write(SESSION_KEY, found.email);
    setUser(found);
  };

  const logout = () => {
    write(SESSION_KEY, null);
    setUser(null);
  };

  const updateProfile = (fields) => {
    const updated = { ...user, ...fields };
    write(USERS_KEY, read(USERS_KEY, []).map((u) => (u.email === user.email ? updated : u)));
    setUser(updated);
  };

  return (
    <AuthContext.Provider value={{ user, ready, register, login, logout, updateProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
