const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export const validateLogin = (v) => {
  const e = {};
  if (!emailRe.test(v.email)) e.email = "Enter a valid email address.";
  if (!v.password) e.password = "Enter your password.";
  return e;
};

export const validateRegister = (v) => {
  const e = {};
  if (v.name.trim().length < 2) e.name = "Enter your full name.";
  if (!emailRe.test(v.email)) e.email = "Enter a valid email address.";
  if (v.password.length < 8 || !/[A-Za-z]/.test(v.password) || !/\d/.test(v.password))
    e.password = "Use at least 8 characters with a letter and a number.";
  if (v.confirm !== v.password) e.confirm = "Passwords do not match.";
  if (!v.branch.trim()) e.branch = "Enter your branch.";
  const cgpa = Number(v.cgpa);
  if (v.cgpa === "" || Number.isNaN(cgpa) || cgpa < 0 || cgpa > 10) e.cgpa = "CGPA must be between 0 and 10.";
  return e;
};

export const validateProfile = (v) => {
  const e = {};
  if (v.name.trim().length < 2) e.name = "Enter your full name.";
  if (!v.branch.trim()) e.branch = "Enter your branch.";
  const cgpa = Number(v.cgpa);
  if (v.cgpa === "" || Number.isNaN(cgpa) || cgpa < 0 || cgpa > 10) e.cgpa = "CGPA must be between 0 and 10.";
  if (v.phone && !/^\d{10}$/.test(v.phone)) e.phone = "Phone number must be 10 digits.";
  return e;
};
