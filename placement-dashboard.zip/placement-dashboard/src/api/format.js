export const formatDate = (iso) =>
  new Date(iso).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });

export const daysLeft = (iso) => {
  const today = new Date(new Date().toDateString());
  return Math.round((new Date(iso) - today) / 86400000);
};

export const deadlineLabel = (iso) => {
  const n = daysLeft(iso);
  if (n < 0) return "Closed";
  if (n === 0) return "Closes today";
  return `${n} day${n === 1 ? "" : "s"} left`;
};
