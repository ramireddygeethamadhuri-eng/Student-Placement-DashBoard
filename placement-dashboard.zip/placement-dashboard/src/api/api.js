// Simulated REST API: reads JSON files from /public/data.
// To use a real backend later, replace getJson() with fetch("https://your-api/...").
const toDate = (days) => {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
};

async function getJson(file) {
  const res = await fetch(`${import.meta.env.BASE_URL}data/${file}`);
  if (!res.ok) throw new Error(`Could not load ${file} (status ${res.status}). Try again.`);
  return res.json();
}

export async function fetchJobs() {
  const jobs = await getJson("jobs.json");
  return jobs.map((j) => ({ ...j, deadline: toDate(j.deadlineInDays), interviewDate: toDate(j.interviewInDays) }));
}

export const fetchTrends = () => getJson("trends.json");

export async function fetchAnnouncements() {
  const items = await getJson("announcements.json");
  return items.map((a) => ({ ...a, date: toDate(-a.daysAgo) }));
}
