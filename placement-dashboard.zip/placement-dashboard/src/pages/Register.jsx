import { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import useForm from "../hooks/useForm.js";
import { validateRegister } from "../hooks/validators.js";
import FormField from "../components/FormField.jsx";

export default function Register() {
  const { user, register } = useAuth();
  const navigate = useNavigate();
  const [formError, setFormError] = useState("");
  const { values, errors, handleChange, handleSubmit } = useForm(
    { name: "", email: "", password: "", confirm: "", branch: "", cgpa: "" },
    validateRegister
  );

  if (user) return <Navigate to="/" replace />;

  const submit = ({ confirm, cgpa, ...rest }) => {
    try {
      register({ ...rest, cgpa: Number(cgpa) });
      navigate("/", { replace: true });
    } catch (err) {
      setFormError(err.message);
    }
  };

  return (
    <div className="auth">
      <form className="panel auth-card" onSubmit={handleSubmit(submit)} noValidate>
        <h1>Create your account</h1>
        {formError && <p className="error" role="alert">{formError}</p>}
        <FormField label="Full name" name="name" autoComplete="name" value={values.name} onChange={handleChange} error={errors.name} />
        <FormField label="Email" name="email" type="email" autoComplete="email" value={values.email} onChange={handleChange} error={errors.email} />
        <div className="row">
          <FormField label="Branch" name="branch" placeholder="e.g. AIML" value={values.branch} onChange={handleChange} error={errors.branch} />
          <FormField label="CGPA" name="cgpa" type="number" step="0.01" min="0" max="10" value={values.cgpa} onChange={handleChange} error={errors.cgpa} />
        </div>
        <FormField label="Password" name="password" type="password" autoComplete="new-password" hint="At least 8 characters, with a letter and a number." value={values.password} onChange={handleChange} error={errors.password} />
        <FormField label="Confirm password" name="confirm" type="password" autoComplete="new-password" value={values.confirm} onChange={handleChange} error={errors.confirm} />
        <button className="btn" type="submit">Create account</button>
        <p className="muted">Already registered? <Link to="/login">Log in</Link></p>
      </form>
    </div>
  );
}
