import { Link } from "react-router-dom";
import { formatDate } from "../api/format.js";
import { STATUSES, useApp } from "../context/AppContext.jsx";

export default function Applications() {
  const { applications, advance } = useApp();
  const interviews = applications
    .filter((a) => a.status === "Interview Scheduled")
    .sort((a, b) => a.interviewDate.localeCompare(b.interviewDate));

  if (applications.length === 0) {
    return (
      <>
        <h1>My applications</h1>
        <p className="empty">You have not applied to any jobs yet. <Link to="/jobs">Browse openings</Link>.</p>
      </>
    );
  }

  return (
    <>
      <h1>My applications</h1>
      <section className="panel">
        <h2>Applied jobs and selection status</h2>
        <div className="table-wrap">
          <table>
            <thead>
              <tr><th>Company</th><th>Role</th><th>Applied on</th><th>Status</th><th><span className="sr-only">Actions</span></th></tr>
            </thead>
            <tbody>
              {applications.map((a) => (
                <tr key={a.jobId}>
                  <td data-label="Company"><strong>{a.company}</strong></td>
                  <td data-label="Role">{a.role}</td>
                  <td data-label="Applied on">{formatDate(a.appliedOn)}</td>
                  <td data-label="Status"><span className={`status s-${STATUSES.indexOf(a.status)}`}>{a.status}</span></td>
                  <td>
                    {a.status !== "Selected" && (
                      <button className="btn small ghost" onClick={() => advance(a.jobId)} title="Demo only: moves to the next stage">
                        Advance (demo)
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="panel">
        <h2>Interview schedule</h2>
        {interviews.length === 0 ? (
          <p className="empty">No interviews scheduled yet. Interviews appear here once a company moves you to that stage.</p>
        ) : (
          <ul className="list">
            {interviews.map((a) => (
              <li key={a.jobId}>
                <div><strong>{a.company}</strong><br /><span className="muted">{a.role}</span></div>
                <div className="right">{formatDate(a.interviewDate)}</div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </>
  );
}
