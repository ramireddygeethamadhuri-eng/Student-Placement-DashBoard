import { formatDate } from "../api/format.js";
import { useApp } from "../context/AppContext.jsx";

const labels = { interview: "Interview alert", company: "Company update", placement: "Placement announcement" };

export default function Notifications() {
  const { notifications } = useApp();
  const all = [...notifications.interviews, ...notifications.others];

  return (
    <>
      <h1>Notifications</h1>
      {all.length === 0 ? (
        <p className="empty">You are all caught up.</p>
      ) : (
        <ul className="notes">
          {all.map((n) => (
            <li key={n.id} className={`note n-${n.type}`}>
              <span className="note-type">{labels[n.type]}</span>
              <h3>{n.title}</h3>
              <p>{n.text}</p>
              <small className="muted">{formatDate(n.date)}</small>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
