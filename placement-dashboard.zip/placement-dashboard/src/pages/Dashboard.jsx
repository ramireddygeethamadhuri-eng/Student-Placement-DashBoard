import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { fetchTrends } from "../api/api.js";
import { daysLeft, deadlineLabel, formatDate } from "../api/format.js";
import { useApp, STATUSES } from "../context/AppContext.jsx";
import { useAuth } from "../context/AuthContext.jsx";
import StatCard from "../components/StatCard.jsx";
import BarChart from "../components/BarChart.jsx";
import LineChart from "../components/LineChart.jsx";
import Loader from "../components/Loader.jsx";
import ErrorMessage from "../components/ErrorMessage.jsx";

export default function Dashboard() {
  const { user } = useAuth();
  const { jobs, loading, error, reload, applications } = useApp();
  const [trends, setTrends] = useState(null);
  const [trendError, setTrendError] = useState("");

  const loadTrends = () => {
    setTrendError("");
    fetchTrends().then(setTrends).catch((e) => setTrendError(e.message));
  };
  useEffect(loadTrends, []);

  if (loading) return <Loader label="Loading dashboard" />;
  if (error) return <ErrorMessage message={error} onRetry={reload} />;

  const count = (s) => applications.filter((a) => a.status === s).length;
  const appliedIds = new Set(applications.map((a) => a.jobId));
  const deadlines = jobs
    .filter((j) => !appliedIds.has(j.id) && daysLeft(j.deadline) >= 0)
    .sort((a, b) => a.deadline.localeCompare(b.deadline))
    .slice(0, 5);

  return (
    <>
      <h1>Welcome, {user.name.split(" ")[0]}</h1>
      <section className="stats">
        <StatCard label="Applications" value={applications.length} />
        <StatCard label="Shortlisted" value={count("Shortlisted")} />
        <StatCard label="Interviews" value={count("Interview Scheduled")} />
        <StatCard label="Offers" value={count("Selected")} />
      </section>

      <section className="two-col">
        <div className="panel">
          <h2>Application statistics</h2>
          {applications.length === 0 ? (
            <p className="empty">No applications yet. <Link to="/jobs">Browse jobs</Link> to apply.</p>
          ) : (
            <BarChart data={STATUSES.map((s) => ({ label: s, value: count(s) }))} />
          )}
        </div>
        <div className="panel">
          <h2>Upcoming deadlines</h2>
          {deadlines.length === 0 ? (
            <p className="empty">No open deadlines. You have applied to everything available.</p>
          ) : (
            <ul className="list">
              {deadlines.map((j) => (
                <li key={j.id}>
                  <div><strong>{j.company}</strong><br /><span className="muted">{j.role}</span></div>
                  <div className="right"><span>{formatDate(j.deadline)}</span><br /><span className={daysLeft(j.deadline) <= 5 ? "urgent" : "muted"}>{deadlineLabel(j.deadline)}</span></div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>

      <section className="two-col">
        {trendError && <ErrorMessage message={trendError} onRetry={loadTrends} />}
        {!trends && !trendError && <Loader label="Loading placement trends" />}
        {trends && (
          <>
            <div className="panel">
              <h2>Placement trends: students placed (%)</h2>
              <LineChart data={trends.years.map((y) => ({ label: y.label, value: y.placedPercent }))} unit="%" label="Percentage of students placed per year" />
            </div>
            <div className="panel">
              <h2>Placements by domain (%)</h2>
              <BarChart data={trends.domains} />
              <p className="muted note">{trends.note}</p>
            </div>
          </>
        )}
      </section>
    </>
  );
}
