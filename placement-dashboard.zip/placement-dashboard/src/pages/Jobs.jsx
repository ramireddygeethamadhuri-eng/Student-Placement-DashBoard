import { useMemo, useState } from "react";
import { useApp } from "../context/AppContext.jsx";
import JobCard from "../components/JobCard.jsx";
import Loader from "../components/Loader.jsx";
import ErrorMessage from "../components/ErrorMessage.jsx";
import { useAuth } from "../context/AuthContext.jsx";

export default function Jobs() {
  const { user } = useAuth();
  const { jobs, loading, error, reload, applications, apply } = useApp();
  const [search, setSearch] = useState("");
  const [type, setType] = useState("All");
  const [eligibleOnly, setEligibleOnly] = useState(false);
  const [message, setMessage] = useState(null);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return jobs.filter((j) => {
      const text = `${j.company} ${j.role} ${j.location} ${j.skills.join(" ")}`.toLowerCase();
      return (
        (!q || text.includes(q)) &&
        (type === "All" || j.type === type) &&
        (!eligibleOnly || Number(user.cgpa) >= j.minCgpa)
      );
    });
  }, [jobs, search, type, eligibleOnly, user.cgpa]);

  const handleApply = (job) => setMessage(apply(job));

  if (loading) return <Loader label="Loading job openings" />;
  if (error) return <ErrorMessage message={error} onRetry={reload} />;

  return (
    <>
      <h1>Job openings</h1>
      <div className="filters panel">
        <div className="field grow">
          <label htmlFor="search">Search by company, role, skill or city</label>
          <input id="search" type="search" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <div className="field">
          <label htmlFor="type">Type</label>
          <select id="type" value={type} onChange={(e) => setType(e.target.value)}>
            <option>All</option>
            <option>Full-time</option>
            <option>Internship</option>
          </select>
        </div>
        <label className="check">
          <input type="checkbox" checked={eligibleOnly} onChange={(e) => setEligibleOnly(e.target.checked)} />
          Only jobs I am eligible for
        </label>
      </div>

      {message && (
        <p className={message.ok ? "success" : "error"} role="status">{message.message}</p>
      )}

      {filtered.length === 0 ? (
        <p className="empty">No jobs match your filters. Clear the search or change the type.</p>
      ) : (
        <section className="job-grid">
          {filtered.map((j) => (
            <JobCard key={j.id} job={j} applied={applications.some((a) => a.jobId === j.id)} onApply={handleApply} />
          ))}
        </section>
      )}
    </>
  );
}
