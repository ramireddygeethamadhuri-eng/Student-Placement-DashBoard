import { useState } from "react";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import useForm from "../hooks/useForm.js";
import { validateLogin } from "../hooks/validators.js";
import FormField from "../components/FormField.jsx";

export default function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [formError, setFormError] = useState("");
  const { values, errors, handleChange, handleSubmit } = useForm({ email: "", password: "" }, validateLogin);

  if (user) return <Navigate to="/" replace />;

  const submit = ({ email, password }) => {
    try {
      login(email, password);
      navigate(location.state?.from || "/", { replace: true });
    } catch (err) {
      setFormError(err.message);
    }
  };

  return (
    <div className="auth">
      <form className="panel auth-card" onSubmit={handleSubmit(submit)} noValidate>
        <h1>Log in to PlaceTrack</h1>
        {formError && <p className="error" role="alert">{formError}</p>}
        <FormField label="Email" name="email" type="email" autoComplete="email" value={values.email} onChange={handleChange} error={errors.email} />
        <FormField label="Password" name="password" type="password" autoComplete="current-password" value={values.password} onChange={handleChange} error={errors.password} />
        <button className="btn" type="submit">Log in</button>
        <p className="muted">New here? <Link to="/register">Create an account</Link></p>
        <p className="muted demo">Demo account: demo@student.edu / Demo@1234</p>
      </form>
    </div>
  );
}
