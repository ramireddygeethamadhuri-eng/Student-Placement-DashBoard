import { useState } from "react";
import { useAuth } from "../context/AuthContext.jsx";
import useForm from "../hooks/useForm.js";
import { validateProfile } from "../hooks/validators.js";
import FormField from "../components/FormField.jsx";

export default function Profile() {
  const { user, updateProfile } = useAuth();
  const [saved, setSaved] = useState(false);
  const { values, errors, handleChange, handleSubmit } = useForm(
    { name: user.name, branch: user.branch, cgpa: String(user.cgpa), phone: user.phone || "", skills: user.skills || "" },
    validateProfile
  );

  const submit = (v) => {
    updateProfile({ ...v, name: v.name.trim(), cgpa: Number(v.cgpa) });
    setSaved(true);
  };

  return (
    <>
      <h1>My profile</h1>
      <form className="panel narrow" onSubmit={handleSubmit(submit)} noValidate onChange={() => setSaved(false)}>
        <FormField label="Full name" name="name" value={values.name} onChange={handleChange} error={errors.name} />
        <p className="muted">Email: {user.email}</p>
        <div className="row">
          <FormField label="Branch" name="branch" value={values.branch} onChange={handleChange} error={errors.branch} />
          <FormField label="CGPA" name="cgpa" type="number" step="0.01" min="0" max="10" value={values.cgpa} onChange={handleChange} error={errors.cgpa} />
        </div>
        <FormField label="Phone" name="phone" inputMode="numeric" hint="10 digits, optional" value={values.phone} onChange={handleChange} error={errors.phone} />
        <FormField label="Skills" name="skills" hint="Separate with commas" value={values.skills} onChange={handleChange} error={errors.skills} />
        <button className="btn" type="submit">Save profile</button>
        {saved && <p className="success" role="status">Profile saved.</p>}
      </form>
    </>
  );
}
