export default function StatCard({ label, value, note }) {
  return (
    <div className="stat">
      <span className="stat-value">{value}</span>
      <span className="stat-label">{label}</span>
      {note && <small className="muted">{note}</small>}
    </div>
  );
}
