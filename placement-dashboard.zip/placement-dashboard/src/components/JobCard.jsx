import { deadlineLabel, formatDate } from "../api/format.js";

export default function JobCard({ job, applied, onApply }) {
  return (
    <article className="job">
      <div className="job-head">
        <div>
          <h3>{job.role}</h3>
          <p className="muted">{job.company} · {job.location}</p>
        </div>
        <span className="tag">{job.type}</span>
      </div>
      <p>{job.description}</p>
      <ul className="skills">
        {job.skills.map((s) => <li key={s}>{s}</li>)}
      </ul>
      <div className="job-foot">
        <div className="job-facts">
          <span><strong>{job.package} LPA</strong></span>
          <span className="muted">Min CGPA {job.minCgpa}</span>
          <span className="muted" title={`Apply by ${formatDate(job.deadline)}`}>{deadlineLabel(job.deadline)}</span>
        </div>
        <button className="btn small" onClick={() => onApply(job)} disabled={applied}>
          {applied ? "Applied" : "Apply"}
        </button>
      </div>
    </article>
  );
}
