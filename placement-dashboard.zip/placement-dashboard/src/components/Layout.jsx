import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import { useApp } from "../context/AppContext.jsx";

export default function Layout() {
  const { user, logout } = useAuth();
  const { notifications } = useApp();
  const navigate = useNavigate();
  const alerts = notifications.interviews.length;

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <>
      <header className="topbar">
        <div className="wrap topbar-inner">
          <span className="brand">PlaceTrack</span>
          <nav aria-label="Main">
            <NavLink to="/" end>Dashboard</NavLink>
            <NavLink to="/jobs">Jobs</NavLink>
            <NavLink to="/applications">Applications</NavLink>
            <NavLink to="/notifications">
              Notifications{alerts > 0 && <span className="badge">{alerts}</span>}
            </NavLink>
            <NavLink to="/profile">Profile</NavLink>
          </nav>
          <div className="user">
            <span className="muted">{user.name}</span>
            <button className="btn small ghost" onClick={handleLogout}>Log out</button>
          </div>
        </div>
      </header>
      <main className="wrap page">
        <Outlet />
      </main>
    </>
  );
}
