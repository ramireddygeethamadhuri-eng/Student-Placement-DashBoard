export default function LineChart({ data, unit = "", label }) {
  const W = 480, H = 230, P = 38;
  const max = Math.max(...data.map((d) => d.value)) * 1.2;
  const x = (i) => P + (i * (W - 2 * P)) / Math.max(data.length - 1, 1);
  const y = (v) => H - P - (v / max) * (H - 2 * P);
  const path = data.map((d, i) => `${i ? "L" : "M"}${x(i)},${y(d.value)}`).join(" ");
  return (
    <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label={label} className="chart">
      <line x1={P} y1={H - P} x2={W - P} y2={H - P} stroke="var(--line)" />
      <path d={path} fill="none" stroke="var(--accent)" strokeWidth="3" strokeLinejoin="round" />
      {data.map((d, i) => (
        <g key={d.label}>
          <circle cx={x(i)} cy={y(d.value)} r="4.5" fill="var(--accent)" />
          <text x={x(i)} y={y(d.value) - 11} textAnchor="middle" className="chart-val">{d.value}{unit}</text>
          <text x={x(i)} y={H - 14} textAnchor="middle" className="chart-lab">{d.label}</text>
        </g>
      ))}
    </svg>
  );
}
