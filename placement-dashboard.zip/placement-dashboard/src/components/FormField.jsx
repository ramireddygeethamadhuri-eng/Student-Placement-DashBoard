export default function FormField({ label, name, error, hint, ...props }) {
  return (
    <div className="field">
      <label htmlFor={name}>{label}</label>
      <input id={name} name={name} aria-invalid={!!error} aria-describedby={error ? `${name}-err` : undefined} {...props} />
      {hint && !error && <small className="muted">{hint}</small>}
      {error && <small id={`${name}-err`} className="err">{error}</small>}
    </div>
  );
}
