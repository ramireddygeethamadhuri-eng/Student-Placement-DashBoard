Add your screenshots here (login.png, dashboard.png, jobs.png, applications.png, notifications.png, profile.png, mobile-view.png).
