# Project Documentation: Student Placement Dashboard

## 1. Overview
PlaceTrack lets students monitor placement opportunities, track applications, prepare for interviews and view placement statistics in a responsive dashboard.

## 2. Requirement coverage
| Requirement | Where it is implemented |
|---|---|
| Login, registration, profile management | `pages/Login.jsx`, `Register.jsx`, `Profile.jsx`, `context/AuthContext.jsx` |
| View job openings | `pages/Jobs.jsx`, `components/JobCard.jsx` |
| Search and filter companies | `pages/Jobs.jsx` (text search, type filter, eligibility filter) |
| Apply for positions | `AppContext.apply()` (checks duplicate, deadline, minimum CGPA) |
| Applied jobs, interview schedule, selection status | `pages/Applications.jsx` |
| Application statistics, placement trends, upcoming deadlines | `pages/Dashboard.jsx`, `BarChart`, `LineChart` |
| Interview alerts, company updates, placement announcements | `pages/Notifications.jsx`, `AppContext` |
| React components, Router, Hooks | whole project; `ProtectedRoute` guards private pages |
| Context API | `AuthContext` (identity) and `AppContext` (data and applications) |
| API integration | `src/api/api.js` fetches JSON from `public/data` |
| Form validation | `hooks/useForm.js` and `hooks/validators.js` |
| Responsive design | `index.css` media queries; tables become cards on mobile |

## 3. Architecture
- **Routing:** public routes `/login`, `/register`; private routes (`/`, `/jobs`, `/applications`, `/notifications`, `/profile`) wrapped in `ProtectedRoute` and `Layout`.
- **State:** `AuthContext` holds the user and session. `AppContext` loads jobs and announcements once, stores each user's applications, and derives notifications.
- **Data flow:** pages read from context, call context actions (`apply`, `advance`), and the UI updates.
- **Error and loading states:** every network call shows a loader and an error message with a retry button.

## 4. Application status flow
Applied → Shortlisted → Interview Scheduled → Selected

## 5. Limitations and future work
- Replace localStorage with a backend (Node/Express + MongoDB or Firebase) and hashed passwords.
- Real notifications by email or push.
- Admin view for the placement cell to post jobs and update statuses.

## 6. UI design screens
Add screenshots of Login, Register, Dashboard, Jobs, Applications, Notifications and Profile to `docs/screens/`.
