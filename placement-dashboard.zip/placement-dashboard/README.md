# Student Placement Dashboard (PlaceTrack)

A React dashboard that helps students find placement openings, track applications and interviews, and view placement statistics.

**Live demo:** _add your deployment link here_
**Demo login:** `demo@student.edu` / `Demo@1234` (or register a new account)

## Features
- **Authentication:** register, log in, log out, edit profile (all forms validated)
- **Placement opportunities:** view openings, search by company/role/skill/city, filter by type, apply (eligibility and deadline checks)
- **Application tracking:** applied jobs, interview schedule, selection status
- **Dashboard analytics:** application statistics, placement trends (line chart), placements by domain, upcoming deadlines
- **Notifications:** interview alerts, company updates, placement announcements
- **Responsive UI** for phone, tablet and desktop

## Tech
React 18, React Router v6 (protected routes), Hooks, Context API, Vite. Charts are plain SVG/CSS (no chart library).

## Project structure
```
public/data/        JSON files acting as the API (jobs, trends, announcements)
src/api/            api.js (fetch layer), format.js (date helpers)
src/context/        AuthContext (users, session), AppContext (jobs, applications, notifications)
src/hooks/          useForm, validators
src/components/     Layout, ProtectedRoute, FormField, StatCard, BarChart, LineChart, JobCard, Loader, ErrorMessage
src/pages/          Login, Register, Dashboard, Jobs, Applications, Notifications, Profile, NotFound
docs/               PROJECT_DOCUMENTATION.md, screens/ (add UI screenshots here)
```

## Run locally
```bash
npm install
npm run dev
```

## Deploy
**Vercel:** import the GitHub repo and deploy (no environment variables needed).
**Netlify:** build command `npm run build`, publish directory `dist`.

## Notes
- Accounts and applications are stored in the browser's localStorage, so this is a front-end learning project. A real system needs a backend with hashed passwords.
- Trend numbers in `public/data/trends.json` are sample data. Replace with your college's figures.
- "Advance (demo)" on the Applications page moves an application to the next stage so you can see every status without a backend.
